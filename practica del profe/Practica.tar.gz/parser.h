int parserDestinatarios(char* path , ArrayList* pArrayListEmployee);
